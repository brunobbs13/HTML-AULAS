//-Jailson � dono de um cinema com duas salas.

//-A sala Alpha possui 140 lugares divididos em 6 fileiras (A, B, C, D, E, F) com mais 12 assentos para pessoas com defici�ncia.
//-A sala Beta possui 120 lugares divididos em 5 fileiras (A, B, C, D, E) com mais 6 lugares para pessoas com defici�ncia.
//-Haver� uma sess�o na Sala Alpha de "As Branquelas" e outra sess�o na Sala Beta de "A Chegada".
//-Construa um programa em que uma pessoa compre um ingresso para qualquer uma das salas e possa escolher a fileira em que vai sentar.
//-O programa deve perguntar, em algum momento, o nome do usu�rio.
//-Uma vez que o assento seja escolhido, � necess�rio que o programa exiba quantos lugares ainda est�o dispon�veis no total e tamb�m em quais fileiras.
//-� importante que o comprador possa escolher a quantidade de ingressos que quer comprar e que ele n�o possa comprar mais ingressos do que a fileira tenha dispon�vel.
//-Ao final, o programa deve exibir a mensagem "[COMPRADOR], seus ingressos foram comprados com sucesso. Aproveite a pipoca gr�tis e tenha um bom filme.".

import java.util.Locale;
import java.util.Scanner;

public class Programainha_do_cineminha {

	public static void main(String[] args) {
		Scanner texto = new Scanner (System.in);
		
		System.out.println("Ol�, Bem vindo(a) ao cinema.");
		System.out.println ("Por motivo de seguran�a, digite seu nome");
		String nome = texto.nextLine();
		
		int lugsala1= 140, lugsala2 = 120, lugdef1 = 12, lugdef2 = 6, opcao, totalsala, totalsala1;
		int a1 = 10, b1 = 26, c1 = 26, d1 = 26, e1 = 26, f1 = 26, pf1 = 12;
		int a2 = 24, b2 = 24, c2 = 24, d2 = 24, e2 = 24, pf2 = 6;
		int ingressos; 
		int fileira1, fileira2, fileiraf, fileiraf1;
		
		
		System.out.println("Qual filme deseja escolher:");
		System.out.println("1- As Branquelas");
		System.out.println("2- A chegada");
		opcao = texto.nextInt();
		
		
		
		if (opcao == 1) {
			System.out.printf("O Filme escolhido foi o de n�mero %d (As Branquelas): \n", opcao);
			System.out.printf("A sala possu� %d lugares disponiveis \n",lugsala1);
			System.out.printf ("A quantidade de lugares nas fileiras s�o: \n FILEIRAS \n 1)A - %d \n 2)B - %d \n 3)C - %d \n 4)D - %d \n 5)E - %d \n 6)F - %d \n 7)G- Assentos preferenciais = %d \n",a1, b1 , c1 , d1 , e1, f1, pf1);
			System.out.println("Digite a fileira que deseja se sentar");
			fileira1 = texto.nextInt();
				
			
			switch(fileira1) {
				case 1:{
					System.out.printf("A quatidade de lugares na fileira (A) �: %d \n",a1);
					System.out.printf("Digite a quantidade de ingressos desejados: ");
					ingressos = texto.nextInt();
					fileiraf = a1 - ingressos;
					System.out.printf("%s, seus %d ingressos foram comprados com sucesso. Aproveite a pipoca gr�tis e tenha um bom filme.\n",nome,ingressos);
					System.out.printf("A quantidade restante de assentos na fileira (A) � de: %d \n",fileiraf);
					totalsala = lugsala1 - fileiraf;
					System.out.printf("A quantidade de salas disponiveis da sala � de: %d \n", totalsala);
					break;
			}	
			
				case 2:{
					System.out.printf("A quatidade de lugares na fileira (B) �: %d \n",b1);
					System.out.printf("Digite a quantidade de ingressos desejados: ");
					ingressos = texto.nextInt();
					fileiraf = b1 - ingressos;
					System.out.printf("%s, seus %d ingressos foram comprados com sucesso. Aproveite a pipoca gr�tis e tenha um bom filme.\n",nome,ingressos);
					System.out.printf("A quantidade restante de assentos na fileira (B) � de: %d \n",fileiraf);
					totalsala = lugsala1 - fileiraf;
					System.out.printf("A quantidade de salas disponiveis da sala � de: %d", totalsala);
					break;
				}
				case 3:{
					System.out.printf("A quatidade de lugares na fileira (C) �: %d \n",c1);
					System.out.printf("Digite a quantidade de ingressos desejados: ");
					ingressos = texto.nextInt();
					fileiraf = c1 - ingressos;
					System.out.printf("%s, seus %d ingressos foram comprados com sucesso. Aproveite a pipoca gr�tis e tenha um bom filme.\n",nome,ingressos);
					System.out.printf("A quantidade restante de assentos na fileira (C) � de: %d \n",fileiraf);
					totalsala = lugsala1 - fileiraf;
					System.out.printf("A quantidade de salas disponiveis da sala � de: %d", totalsala);
					break;
				}
				case 4:{
					System.out.printf("A quatidade de lugares na fileira (D) �: %d \n",d1);
					System.out.printf("Digite a quantidade de ingressos desejados: ");
					ingressos = texto.nextInt();
					fileiraf = d1 - ingressos;
					System.out.printf("%s, seus %d ingressos foram comprados com sucesso. Aproveite a pipoca gr�tis e tenha um bom filme.\n",nome,ingressos);
					System.out.printf("A quantidade restante de assentos na fileira (D) � de: %d \n",fileiraf);
					totalsala = lugsala1 - fileiraf;
					System.out.printf("A quantidade de salas disponiveis da sala � de: %d", totalsala);
					break;
				}
				case 5:{
					System.out.printf("A quatidade de lugares na fileira (E) �: %d \n",e1);
					System.out.printf("Digite a quantidade de ingressos desejados: ");
					ingressos = texto.nextInt();
					fileiraf = e1 - ingressos;
					System.out.printf("%s, seus %d ingressos foram comprados com sucesso. Aproveite a pipoca gr�tis e tenha um bom filme.\n",nome,ingressos);
					System.out.printf("A quantidade restante de assentos na fileira (E) � de: %d \n",fileiraf);
					totalsala = lugsala1 - fileiraf;
					System.out.printf("A quantidade de salas disponiveis da sala � de: %d", totalsala);
					break;
				}
				case 6:{
					System.out.printf("A quatidade de lugares na fileira (F) �: %d \n",f1);
					System.out.printf("Digite a quantidade de ingressos desejados: ");
					ingressos = texto.nextInt();
					fileiraf = f1 - ingressos;
					System.out.printf("%s, seus %d ingressos foram comprados com sucesso. Aproveite a pipoca gr�tis e tenha um bom filme.\n",nome,ingressos);
					System.out.printf("A quantidade restante de assentos na fileira (F) � de: %d \n",fileiraf);
					totalsala = lugsala1 - fileiraf;
					System.out.printf("A quantidade de salas disponiveis da sala � de: %d", totalsala);
					break;
				}
				case 7:{
					System.out.printf("A quatidade de lugares na fileira (Preferencial) �: %d \n",pf1);
					System.out.printf("Digite a quantidade de ingressos desejados: ");
					ingressos = texto.nextInt();
					fileiraf = pf1 - ingressos;
					System.out.printf("%s, seus %d ingressos foram comprados com sucesso. Aproveite a pipoca gr�tis e tenha um bom filme.\n",nome,ingressos);
					System.out.printf("A quantidade restante de assentos preferenciais � de: %d \n",fileiraf);
					totalsala = lugsala1 - fileiraf;
					System.out.printf("A quantidade de salas disponiveis da sala � de: %d", totalsala);
					break;
				}
				
			}
		}	
			
		//opa��o 2
			if (opcao == 2) {
				System.out.printf("O Filme escolhido foi o de n�mero %d (A chegada): \n", opcao);
				System.out.printf("A sala possu� %d lugares disponiveis \n",lugsala2);
				System.out.printf ("A quantidade de lugares nas fileiras s�o: \n FILEIRAS \n 1)A - %d \n 2)B - %d \n 3)C - %d \n 4)D - %d \n 5)E - %d \n 6) Assentos preferenciais = %d \n",a2, b2 , c2 , d2 , e2, pf2);
				System.out.println("Digite a fileira que deseja se sentar");
				fileira2 = texto.nextInt();
				
			
				
				switch(fileira2) {
					case 1:{
						System.out.printf("A quatidade de lugares na fileira (A) �: %d \n",a2);
						System.out.printf("Digite a quantidade de ingressos desejados: ");
						ingressos = texto.nextInt();
						fileiraf = a2 - ingressos;
						System.out.printf("%s, seus %d ingressos foram comprados com sucesso. Aproveite a pipoca gr�tis e tenha um bom filme.\n",nome,ingressos);
						System.out.printf("A quantidade restante de assentos na fileira (A) � de: %d \n",fileiraf);
						totalsala = lugsala2 - fileiraf;
						System.out.printf("A quantidade de salas disponiveis da sala � de: %d \n", totalsala);
						break;
				}	
				
					case 2:{
						System.out.printf("A quatidade de lugares na fileira (B) �: %d \n",b2);
						System.out.printf("Digite a quantidade de ingressos desejados: ");
						ingressos = texto.nextInt();
						fileiraf = b2 - ingressos;
						System.out.printf("%s, seus %d ingressos foram comprados com sucesso. Aproveite a pipoca gr�tis e tenha um bom filme.\n",nome,ingressos);
						System.out.printf("A quantidade restante de assentos na fileira (B) � de: %d \n",fileiraf);
						totalsala = lugsala2 - fileiraf;
						System.out.printf("A quantidade de salas disponiveis da sala � de: %d", totalsala);
						break;
					}
					case 3:{
						System.out.printf("A quatidade de lugares na fileira (C) �: %d \n",c2);
						System.out.printf("Digite a quantidade de ingressos desejados: ");
						ingressos = texto.nextInt();
						fileiraf = c2 - ingressos;
						System.out.printf("%s, seus %d ingressos foram comprados com sucesso. Aproveite a pipoca gr�tis e tenha um bom filme.\n",nome,ingressos);
						System.out.printf("A quantidade restante de assentos na fileira (C) � de: %d \n",fileiraf);
						totalsala = lugsala2 - fileiraf;
						System.out.printf("A quantidade de salas disponiveis da sala � de: %d", totalsala);
						break;
					}
					case 4:{
						System.out.printf("A quatidade de lugares na fileira (D) �: %d \n",d2);
						System.out.printf("Digite a quantidade de ingressos desejados: ");
						ingressos = texto.nextInt();
						fileiraf = d2 - ingressos;
						System.out.printf("%s, seus %d ingressos foram comprados com sucesso. Aproveite a pipoca gr�tis e tenha um bom filme.\n",nome,ingressos);
						System.out.printf("A quantidade restante de assentos na fileira (D) � de: %d \n",fileiraf);
						totalsala = lugsala2 - fileiraf;
						System.out.printf("A quantidade de salas disponiveis da sala � de: %d", totalsala);
						break;
					}
					case 5:{
						System.out.printf("A quatidade de lugares na fileira (E) �: %d \n",e2);
						System.out.printf("Digite a quantidade de ingressos desejados: ");
						ingressos = texto.nextInt();
						fileiraf = e2 - ingressos;
						System.out.printf("%s, seus %d ingressos foram comprados com sucesso. Aproveite a pipoca gr�tis e tenha um bom filme.\n",nome,ingressos);
						System.out.printf("A quantidade restante de assentos na fileira (E) � de: %d \n",fileiraf);
						totalsala = lugsala2 - fileiraf;
						System.out.printf("A quantidade de salas disponiveis da sala � de: %d", totalsala);
						break;
					}
					case 6:{
						System.out.printf("A quatidade de lugares na fileira (Preferencial) �: %d \n",pf2);
						System.out.printf("Digite a quantidade de ingressos desejados: ");
						ingressos = texto.nextInt();
						fileiraf = pf2 - ingressos;
						System.out.printf("%s, seus %d ingressos foram comprados com sucesso. Aproveite a pipoca gr�tis e tenha um bom filme.\n",nome,ingressos);
						System.out.printf("A quantidade restante de assentos preferenciais � de: %d \n",fileiraf);
						totalsala = lugsala2 - fileiraf;
						System.out.printf("A quantidade de salas disponiveis da sala � de: %d", totalsala);
						break;
					}
					
				}
		
			}
		}	
	}
	

	

		
