import java.util.Scanner;

public class UsandoVariaveis {

	public static void main(String[] args) {
		Scanner texto = new Scanner (System.in); 
		
		String nome;
		Byte idade;
		
		System.out.println("Digite o primeiro nome");
		nome = texto.nextLine();
		System.out.printf("Ol�, "+ nome);
		System.out.println("\nDigite sua idade");
		idade = texto.nextByte();
		
		System.out.printf("Ol� %s,fico feliz em saber que voc� tem %d anos.", nome,idade);
		
		texto.close();
	}

}
